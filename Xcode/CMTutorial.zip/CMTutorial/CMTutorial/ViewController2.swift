//
//  ViewController2.swift
//  CMTutorial
//
//  Created by user on 2017. 7. 15..
//  Copyright © 2017년 user. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController2: UIViewController {
    
    let manager = CMMotionManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager.accelerometerUpdateInterval = 0.6
        
        manager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
            if let myData1 = data
            {
                if myData1.acceleration.y > -0.5 {
                    self.performSegue(withIdentifier: "twoToOne", sender: self)
                }
                
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
