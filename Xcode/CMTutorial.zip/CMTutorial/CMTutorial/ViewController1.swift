//
//  ViewController.swift
//  CMTutorial
//
//  Created by user on 2017. 7. 15..
//  Copyright © 2017년 user. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    let manager = CMMotionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager.accelerometerUpdateInterval = 0.6
        
        manager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
            if let myData1 = data
            {
                if myData1.acceleration.y < -0.8 {
                    self.performSegue(withIdentifier: "oneToTwo", sender: self)
                }
                
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

